
============ Instruction ============
1. Open the index.php file and change the SMTP username and password with your email address and Gmail password. 

2. Set From email, ReplyTo email and add a recipient email.

3. Insert HTML body content into the $bodyContent variable.

4. Run the index.php file on the browser and check recipient email account.


============ May I Help You ===========

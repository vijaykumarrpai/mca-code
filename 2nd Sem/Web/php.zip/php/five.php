<!DOCTYPE html>
<html lang="en">
<head>
    <title>PHP Strings</title>
</head>
<body>

<?php
$a = 'Hello world!';
echo $a;
echo "<br>";
 
$b = "Hello world!";
echo $b;
echo "<br>";
 
$c = 'Stay here, I\'ll be back.';
echo $c;
?>

</body>
</html>       
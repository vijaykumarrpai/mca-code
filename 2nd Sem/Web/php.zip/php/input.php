<html>
<body>
<?php
$myname=$_GET["name"];
echo $myname;
?>
Welcome <?php echo $_GET["myname"]; ?><br>
Your email address is: <?php echo $_GET["email"]; ?>

</body>
</html>




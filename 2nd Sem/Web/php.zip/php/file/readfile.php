<!DOCTYPE html>
<html>
<body>

<?php
echo readfile("dictionary.txt");
?>

</body>
</html>
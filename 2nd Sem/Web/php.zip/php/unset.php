<?php
$xyz='PESIT is now PES University';
echo 'Before using unset() the value of $xyz is : '. $xyz.'<br/>';
unset($xyz);
echo 'After using unset() the value of $xyZ is : '. $xyz;
?> 
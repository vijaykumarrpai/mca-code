<?php
echo "<h2>Hello! R u learning php???</h2>";
?>

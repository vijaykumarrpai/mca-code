<?php
echo("floor(Laregest Integer-Less than or Equal to the Parameter)<br />");
echo(floor(0.60) . "<br />");
echo(floor(0.40) . "<br />");
echo(floor(5) . "<br />");
echo(floor(5.1) . "<br />");
echo(floor(-5.1) . "<br />");
echo(floor(-5.9));

echo("<br />ceil-(Smaller Integer Greater than or equal to the parameter)");
echo("<br />");
echo(ceil(0.60) . "<br />");
echo(ceil(0.40) . "<br />");
echo(ceil(5) . "<br />");
echo(ceil(5.1) . "<br />");
echo(ceil(-5.1) . "<br />");
echo(ceil(-5.9));


echo("<br />round- Nearest Integer");
echo("<br />");
echo(round(0.60) . "<br />");
echo(round(0.40) . "<br />");
echo(round(0.50) . "<br />");
echo(round(5) . "<br />");
echo(round(5.1) . "<br />");
echo(round(-5.1) . "<br />");
echo(round(-5.9));

echo("<br />abs- (Absololute value of parameter)");
echo("<br />");
echo(abs(0.60) . "<br />");
echo(abs(0.40) . "<br />");
echo(abs(5) . "<br />");
echo(abs(5.1) . "<br />");
echo(abs(-5.1) . "<br />");
echo(abs(-5.9));

?>
<?php  
    echo gettype(102).'<br>';  
    echo gettype(true).'<br>';  
    echo gettype(' ').'<br>';  
    echo gettype(null).'<br>';  
    echo gettype(array()).'<br>';  
    echo gettype(new stdclass());  
?>  
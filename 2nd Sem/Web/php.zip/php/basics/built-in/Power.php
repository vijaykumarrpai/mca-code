<?php
        $a = 7;
        $b = 7;
        if ($a == $b) {
           $a = 3 * $a;
        ?>
<br /> At this point, $a and $b are equal <br />
So, we change $a to three times $a= 
        <?php
			print $a;}
         ?>     

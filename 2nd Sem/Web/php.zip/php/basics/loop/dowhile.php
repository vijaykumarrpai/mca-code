<?php
/*do
{
   code to be executed;
}while (condition);
*/
$i = 0;
$num = 0;
do
{
  $i++;
}while( $i < 10 );
echo ("Loop stopped at i = $i" );
?>

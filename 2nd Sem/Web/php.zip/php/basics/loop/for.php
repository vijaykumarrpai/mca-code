<?php
/*
for (init counter; test counter; increment counter) {
    code to be executed;
} */
for ($x = 0; $x <= 10; $x++) {
    echo "The number is: $x <br>";
}
?> 
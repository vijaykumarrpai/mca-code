<?php

/***
 * printf()  is used to "PRINT" some formatted string
 * sprintf() is used to "STORE" some formatted string, and print it with the help
 * of echo or print
 * */

  printf("%d", "65"); //INT 65
  echo '<br>';

  printf("%c", "65"); // CHAR A
   echo '<br>';

  printf("%f", "65"); // FLOAT 65.000000
  echo '<br>';

  printf("testing right now [%s] [%s]", "Hello Zend", "Hello PHP");
  //testing right now [Hello Zend] [Hello PHP]
  ?>
<!DOCTYPE html>
<html>
<head>
<style>
#mystyle {color:red; font-size:20px;}

</style>
</head>
<?php
echo "Say hello to PHP<br />";
echo "<div id=\"mystyle\">Hello to PHP</div>";


?>
</html>
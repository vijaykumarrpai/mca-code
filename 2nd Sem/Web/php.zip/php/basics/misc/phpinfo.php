<?php
echo 'hello';
phpinfo();
?>

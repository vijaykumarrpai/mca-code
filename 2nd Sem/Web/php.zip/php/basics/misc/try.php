<!DOCTYPE html>
<html>
<head>
<style>
#mystyle{ color:green;
       font-size: 20pt}
</style>
</head>
<body>

<?php
echo "<div id='mystyle'>Welcome to Server Programming</div>";
?>

</body>
</html>
<?php
//-Use of ID key
$employee_array[0] = "Raj";
$employee_array[1] = "Sanjay";
$employee_array[2] = "Mahesh";
$employee_array[3] = "Ram";

echo $employee_array[0]." and ".$employee_array[1]."are friends.<br />";
$cars=array("Raj","Sanjay","Mahesh","Ram"); 
echo $cars[1],"<br/>";

$person[0] = "Edison";
$person[1] = "Wankel";
$person[2] = "Crapper";

$creator['Light bulb'] = "Edison";
$creator['Rotary Engine'] = "Wankel";
$creator['Toilet'] = "Crapper";

print $creator['Light bulb']."<br/>";
print $creator['Rotary Engine']."<br/>";
?> 

 <?php
$cars = array("Volvo","","Toyota");
echo "<br/>";
var_dump($cars);
?> 
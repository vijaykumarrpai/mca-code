<!DOCTYPE html>
<html lang="en">
<head>
    <title>PHP Booleans</title>
</head>
<body>

<?php
// Assign the value TRUE to a variable
$show_error = True;
var_dump($show_error);
?>

</body>
</html>  
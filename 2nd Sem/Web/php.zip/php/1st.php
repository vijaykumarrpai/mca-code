<?php
echo "hello world";
#first program
?>
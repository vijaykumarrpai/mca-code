<!DOCTYPE html>
<html>
<body>

<a href="$_get.php?subject=PHP&web=http://myweb.edu">Test $GET</a>

</body>
</html>
<?php
$abc=10;
echo "The value is".$abc;
$abc="PES UNIVERSITY";
print $abc;
?>

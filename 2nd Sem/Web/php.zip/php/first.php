<!DOCTYPE HTML>
<html>
<head>
    <title>PHP Hello World Application</title>
</head>
<body>

<?php
// Simple greeting message
echo "Hello, world!";
?>

</body>
</html> 
<!DOCTYPE html>
<html>
<body>

<?php
date_default_timezone_set("Asia/Calcutta");
echo "The time is " . date("h:i:sa");
?>

</body>
</html>
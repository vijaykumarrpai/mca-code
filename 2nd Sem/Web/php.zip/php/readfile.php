<?php
echo readfile("test.txt");
?>

<!DOCTYPE html>
<html>
<body>

<a href="test_get.php?subject=PHP&web=PES University">Test $GET</a>

</body>
</html>
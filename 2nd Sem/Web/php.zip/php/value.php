<?php
$abc=10;
print $abc."</br>";
$abc=2;
echo $abc."</br>";
$abc=15.2;
$abc="Hello from php";
echo "</br>hello\t".$abc;
?>
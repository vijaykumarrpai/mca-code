<?php
#Return the absolute value of different numbers:
echo "Absolute Value <br />";
echo(abs(6.7) . "<br />");
echo(abs(-6.7) . "<br />");
echo(abs(-3) . "<br />");
echo(abs(3). "<br />");
?> 
<?php
#Find lowest value with the min() function:
echo "Minimum Value";
echo "<br />";
echo(min(2,4,6,8,10) . "<br />");
echo(min(22,14,68,18,15) . "<br />");
echo(min(array(4,6,8,10)) . "<br />");
echo(min(array(44,16,81,12)). "<br />");
?> 


<?php
#Find highest value with the max() function:
echo "Maximum Value";
echo "<br />";
echo(max(2,4,6,8,10) . "<br />");
echo(max(22,14,68,18,15) . "<br />");
echo(max(array(4,6,8,10)) . "<br />");
echo(max(array(44,16,81,12)). "<br />");
?>

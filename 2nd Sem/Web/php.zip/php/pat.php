<!DOCTYPE html>
<html>
<body>

<form action="pat.php">
  Country code: <input type="text" name="country_code" pattern="[A-Za-z]{3}" title="Three letter country code">
  <input type="submit">
</form>

</body>
</html>
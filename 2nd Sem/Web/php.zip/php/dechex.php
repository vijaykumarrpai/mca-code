<!DOCTYPE html>
<html>
<body>

<?php
echo dechex("30") . "<br>";
echo dechex("10") . "<br>";
echo dechex("1587") . "<br>";
echo dechex("70");
//decoct
?>

</body>
</html>
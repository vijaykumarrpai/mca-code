<!DOCTYPE html>
<html lang="en">
<head>
    <title>PHP Variables</title>
</head>
<body>

<?php
$txt = "Hello World!";
$number = 10;

// Display variables value
echo $txt;
echo "<br>";
echo $number;
?>

</body>
</html>  